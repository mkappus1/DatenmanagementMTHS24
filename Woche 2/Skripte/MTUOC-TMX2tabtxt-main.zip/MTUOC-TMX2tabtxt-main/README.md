# MTUOC-TMX2tabtxt
Scripts to convert TMX files into tab txt files. 
